package com.cognizant.dao;

import com.cognizant.model.Exam;

public interface ExamDao {
	
	public boolean insert(Exam exam);
	
	
}

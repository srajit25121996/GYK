package com.cognizant.dao;

import com.cognizant.model.Assessment;

public interface AssessmentDao {
	
	public boolean insert(Assessment assessment);
	public int getAssessmentid();
	
}
